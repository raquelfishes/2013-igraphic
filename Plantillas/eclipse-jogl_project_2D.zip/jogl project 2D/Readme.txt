Project skeleton for Computer 2D Graphics 
--------------------------
Java: JDK 7
Graphics Library: JOGL 2.0
--------------------------
IDE: Eclipse 4.3 (Kepler)
Workplace: jogl project 2D
Project: project 2D
--------------------------
Autor: Pedro J. Mart�n de la Calle
Date: 11-10-2013
