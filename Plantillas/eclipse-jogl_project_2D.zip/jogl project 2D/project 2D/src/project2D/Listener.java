package project2D;

import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GL2;
import javax.media.opengl.GL;
import javax.media.opengl.fixedfunc.GLMatrixFunc;
import javax.media.opengl.glu.GLU;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Listener implements GLEventListener, KeyListener{

	// Scene visible area size
	private double xLeft, xRight, yTop, yBot;

	private GLU glu;
	
	// Scene variables
	private double xTriangle, yTriangle;
	private double triangleWidth, triangleHeight;
	
	//For repainting
	private GLAutoDrawable canvas;
	
	
	public Listener(int pv_width, int pv_height, GLAutoDrawable canvas){
		glu= new GLU();
		
		xLeft=0; xRight= (double)pv_width;
        yBot=0;  yTop= (double)pv_height;
        
        this.canvas= canvas;
        
        triangleWidth= 0.4*(xRight-xLeft);
        triangleHeight= 0.8*(yTop-yBot);    
        xTriangle= xLeft + 0.3*(xRight-xLeft);
        yTriangle= yBot + 0.1*(yTop-yBot);;
    }
	
	@Override
	public void init(GLAutoDrawable drawable) {
		GL2 gl = drawable.getGL().getGL2();

		gl.glClearColor(1, 1, 1, 1);
		gl.glColor3f(1.0f,0.0f,0.0f); 

		gl.glPointSize(4.0f);
		gl.glLineWidth(2.0f);

        gl.glMatrixMode(GLMatrixFunc.GL_PROJECTION);
        gl.glLoadIdentity();
		glu.gluOrtho2D(xLeft,xRight, yBot,yTop);
		
		gl.glMatrixMode(GLMatrixFunc.GL_MODELVIEW);
		gl.glLoadIdentity();
	}

	@Override
	public void dispose(GLAutoDrawable drawable) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void display(GLAutoDrawable drawable) {
		
		GL2 gl = drawable.getGL().getGL2();

        gl.glClear(GL.GL_COLOR_BUFFER_BIT);

        gl.glBegin(GL.GL_TRIANGLES);
	        gl.glVertex2d( xTriangle, yTriangle );
	        gl.glVertex2d( xTriangle + triangleWidth, yTriangle );
	        gl.glVertex2d( xTriangle + triangleWidth/2.0, yTriangle + triangleHeight );
        gl.glEnd();
        
        gl.glFlush();
		
	}

	@Override
	public void reshape(GLAutoDrawable drawable, int x, int y, int width,
			int height) {

		double RatioViewPort= (double)width/(double)height;		
		double RatioVolVista=(xRight-xLeft)/(yTop-yBot);
		
		if (RatioVolVista>=RatioViewPort){
			     //Aumentamos yTop-yBot
			     double altoNew= (xRight-xLeft)/RatioViewPort;
			     double yCentro= (yBot+yTop)/2.0;
			     yTop= yCentro + altoNew/2.0;
			     yBot= yCentro - altoNew/2.0;
		}
		else{
			//Aumentamos xRight-xLeft
			double anchoNew= RatioViewPort*(yTop-yBot);
			double xCentro= (xLeft+xRight)/2.0;
			xRight= xCentro + anchoNew/2.0;
			xLeft= xCentro - anchoNew/2.0;
		}

		
		GL2 gl = drawable.getGL().getGL2();
        gl.glMatrixMode(GLMatrixFunc.GL_PROJECTION);
        gl.glLoadIdentity();
		glu.gluOrtho2D(xLeft,xRight, yBot,yTop);
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		switch(e.getKeyCode()){
			case KeyEvent.VK_RIGHT: xTriangle += 10; break;
			case KeyEvent.VK_LEFT:  xTriangle -= 10; break;
		}
		
		canvas.display();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	public void left(){
		xTriangle -= 10;
		canvas.display();
	}

	public void right(){
		xTriangle += 10;
		canvas.display();
	}
}
