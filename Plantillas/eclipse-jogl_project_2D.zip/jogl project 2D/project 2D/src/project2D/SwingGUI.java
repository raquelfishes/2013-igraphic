package project2D;

import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLProfile;
//import javax.media.opengl.awt.GLCanvas;
import javax.media.opengl.awt.GLJPanel;

//Swing imports
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class SwingGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private Listener listener;
	private GLJPanel canvas;
	
	private SwingGUI(){

		super("Swing Window");
		this.getContentPane().setLayout(new BorderLayout());
		int width= 522;
		int height= 341;		
		this.setSize(width, height);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
		GLProfile glp = GLProfile.getDefault();
        GLCapabilities caps = new GLCapabilities(glp);
 
        canvas = new GLJPanel(caps);
        this.getContentPane().add(canvas,BorderLayout.CENTER);
  
        
        listener= new Listener(width, height, canvas);
        canvas.addGLEventListener(listener);
        canvas.addKeyListener(listener);
        
        
        JPanel btPane= new JPanel();
        this.getContentPane().add(btPane,BorderLayout.SOUTH);

        JButton button_left = new JButton("Left");
        button_left.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent e){
        		listener.left();
        	}
        });
        btPane.add(button_left,BorderLayout.WEST);


        JButton button_right = new JButton("Right");
        button_right.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent e){
        		listener.right();
        	}
        });
        btPane.add(button_right,BorderLayout.EAST);
	}
	
	public static void main(String[] args) {
		
        SwingGUI app = new SwingGUI();
        app.setVisible(true);
	}

}
